#include <seccomp.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

static void init(void) {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
}
int main(void) {
  init();
  char buf[7] = {0};
  puts("first time bikin soal buat anak sma/smk tolong jangan dihujat yah "
       "`(*>﹏<*)′");
  ssize_t n = read(0, buf, sizeof(buf) - 1);
  if (n < 0) {
    perror("read");
    _exit(1);
  }
  void *sc = mmap(0, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC,
                  MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (sc == MAP_FAILED) {
    puts("something went wrong ＞︿＜");
    _exit(1);
  };
  if (memcpy(sc, buf, sizeof(buf)) == NULL) {
    puts("something went wrong ＞︿＜");
    _exit(1);
  };
  ((void (*)(void))sc)();
}
