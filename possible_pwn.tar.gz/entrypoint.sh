#!/bin/bash

echo $GZCTF_FLAG > /home/mirai/flag.txt
chmod 444 /home/mirai/flag.txt

unset GZCTF_FLAG
exec socat TCP-LISTEN:1337,reuseaddr,fork,su=mirai EXEC:'timeout 180 ./chall'
